#include <cstdio>

void printFibonacciSequence(unsigned int limit) {
    unsigned int x, y, z;
    x = 0;
    y = 1;
    do {
        printf("%d, ", x);
        z = x + y;
        x = y;
        y = z;
    } while (x < limit);
}

unsigned long fibonacci(unsigned long n) {
    if (n < 2)
        return n;
    else
        return fibonacci(n - 1) + fibonacci(n - 2);
}
