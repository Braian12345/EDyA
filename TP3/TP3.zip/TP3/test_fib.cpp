#include "lib.h"
#include <cstdlib>
#include <cstdio>

int main(int argc, char const *argv[]) {
    if (argc == 3) {
        unsigned long fn = fibonacci(atol(argv[1]));
        unsigned long r = atol(argv[2]);
        return fn==r?0:1;
    }
    /* code */
    return 1;
}

