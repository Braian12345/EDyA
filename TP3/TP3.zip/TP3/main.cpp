#include <iostream>
#include <vector>
#include "lib.h"
#include <cstdlib>
#include <ctime>

using namespace std;

vector<unsigned int> create(unsigned int N, unsigned int from, unsigned int to){
    srand(time(0));
   
    vector<unsigned int> vec(N);
    unsigned int range = to-from+1;
    
    for(auto &i:vec){
        i=rand() % range + from;
    }

    return vec;
}

void sort(vector<unsigned int> &v){
    unsigned int temp;

    for(unsigned int i=0; i<v.size(); i++){
        for(unsigned int j=0; j<v.size()-1; j++){
            if(v[j]>v[j+1]){
                temp = v[j];
                v[j] = v[j+1];
                v[j+1] = temp;
            }
        }
    }
}

/*vector<unsigned int> insert1(vector<unsigned int> v1, vector<unsigned int> v2,
unsigned int pos){

    unsigned int i, j=0;        
    for(i=pos; i!=v2.size(); i++){
        v1.insert(i, v2[j]);
        j++;
    }
    
    return v;
}*/



int main(int, char **){

    vector<unsigned int> v = create(5,50,100);
    vector<unsigned int> v2(5,7);

    cout<<"hola";

    return 0;
}






