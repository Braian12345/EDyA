#include <string>
#include "../edya_stl.h"

int main(int argc, char const *argv[]) {
    if (argc == 3) {
        std::string i = argv[1];
        std::string o = argv[2];
        return palindromePyramid(i) == o ? 0 : 1;
    }
    return 1;
}
