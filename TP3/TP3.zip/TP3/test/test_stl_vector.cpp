#include <string>
#include<algorithm>
#include <vector>
#include "../edya_stl.h"

int testInsert() {
    const std::vector<unsigned int> v1 = {1, 2, 3, 4};
    const std::vector<unsigned int> v2 = {6, 7, 8};
    const std::vector<unsigned int> v3 = insert(v1, v2, 1);
    const std::vector<unsigned int> vr = {1, 6, 7, 8, 2, 3, 4};
    return v3 == vr ? 0 : 1;
}

int testInsertAtTheEnd() {
    std::vector<unsigned int> v1 = {1, 2, 3, 4};
    std::vector<unsigned int> v2 = {6, 7, 8};
    std::vector<unsigned int> v3 = insert(v1, v2, 111);
    std::vector<unsigned int> vr = {1, 2, 3, 4, 6, 7, 8};
    return v3 == vr ? 0 : 1;
}

int testInsertAtTheBegin() {
    const std::vector<unsigned int> v1 = {1, 2, 3, 4};
    const std::vector<unsigned int> v2 = {6, 7, 8};
    const std::vector<unsigned int> v3 = insert(v1, v2, 0);
    const std::vector<unsigned int> vr = {6, 7, 8, 1, 2, 3, 4};
    return v3 == vr ? 0 : 1;
}

int testSort(std::vector<unsigned int> v) {
    std::vector<unsigned int> vr = std::vector<unsigned int>(v);
    std::sort(vr.begin(), vr.end());
    sort(v);
    return v == vr ? 0 : 1;
}


int testCreate() {
    const int from = 4;
    const int to = 9;
    std::vector<unsigned int> v = create(5, from, to);
    if (v.front() < from)
        return 1;
    if (v.back() > to)
        return 1;
    if (v.size() != to - from)
        return 1;
    if (v.capacity() < to - from)
        return 1;
    return 0;
}


int main(int argc, char const *argv[]) {
    if (argc > 1) {
        std::string option = std::string(argv[1]);
        if (option == "create") {
            return testCreate();
        } else if (option == "insert") {
            return testInsert();
        } else if (option == "insertEnd") {
            return testInsertAtTheEnd();
        } else if (option == "insertBegin") {
            return testInsertAtTheBegin();
        } else if (option == "sort") {
            std::vector<unsigned int> v;
            for (size_t i = 2; i < argc; ++i) {
                v.push_back(atoi(argv[i]));
            }
            return testSort(v);
        } else {
            return 1;
        }
    }
    return 1;
}
