#include <string>
#include "../edya_stl.h"

int main(int argc, char const *argv[]) {
    if (argc == 5) {
        std::string str = argv[1];
        std::string from = argv[2];
        std::string to = argv[3];
        std::string result = argv[4];
        return replaceAll(str, from, to) == result ? 0 : 1;
    }
    return 1;
}
