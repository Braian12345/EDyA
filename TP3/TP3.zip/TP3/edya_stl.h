#ifndef EDYA_STL_H
#define EDYA_STL_H

/* EJERCICIO 1
void stringAT(string example){
    for(unsigned int i=0; i<example.length(); i++)
        cout<<example.at(i)<<" ";
}

void stringINDEX(string example){
    for(unsigned int i=0; i<example.length(); i++)
        cout<<example[i]<<" ";
}

void stringITERATOR(string example){
    for(auto i=example.begin(); i!=example.end(); i++)
        cout<<*i<<" ";
}

void stringEACH(string example){
    for(char letter:example)
        cout<<letter<<" ";
}

*/

#endif
